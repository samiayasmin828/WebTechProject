-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2020 at 06:43 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `pass`, `type`, `status`) VALUES
('admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'active'),
('mina@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Tutor', 'active'),
('mithu@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Student', 'active'),
('rahman@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Student', 'active'),
('raju@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'Student', 'active'),
('samia@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Student', 'active'),
('samiatutor@gmail.com', 'fb62579e990da4e2a8f15c3d1e123438', 'Tutor', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE `sms` (
  `sender` varchar(50) NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `sms` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stueducationinfo`
--

CREATE TABLE `stueducationinfo` (
  `email` varchar(100) NOT NULL,
  `insname` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `medium` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stueducationinfo`
--

INSERT INTO `stueducationinfo` (`email`, `insname`, `class`, `medium`) VALUES
('raju@gmail.com', 'HURDCO International School', 'Three', 'Bangla Medium'),
('mithu@gmail.com', '', '', ''),
('rahman@gmail.com', 'Ideal Public School And College', 'Seven', 'English Medium'),
('samia@gmail.com', 'Viqarunisa Noon School & College', 'Eight', 'Bangla Medium');

-- --------------------------------------------------------

--
-- Table structure for table `stupersonalinfo`
--

CREATE TABLE `stupersonalinfo` (
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `phoneno` varchar(11) NOT NULL,
  `gender` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stupersonalinfo`
--

INSERT INTO `stupersonalinfo` (`email`, `name`, `dob`, `address`, `phoneno`, `gender`) VALUES
('raju@gmail.com', 'Raju Ahmed ', '1998-09-15', 'Abdullahpur', '01912345678', 'Male'),
('mithu@gmail.com', '', '0000-00-00', '', '', ''),
('rahman@gmail.com', 'Md Rahman', '2019-12-24', 'Dhanmondi', '01788888232', 'Male'),
('samia@gmail.com', 'Samia Yasmin', '1998-08-28', 'Motijheel', '01911538983', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `tbsc`
--

CREATE TABLE `tbsc` (
  `email` varchar(100) NOT NULL,
  `insname` varchar(100) NOT NULL,
  `passingyear` varchar(4) NOT NULL,
  `dept` varchar(100) NOT NULL,
  `result` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbsc`
--

INSERT INTO `tbsc` (`email`, `insname`, `passingyear`, `dept`, `result`) VALUES
('mina@gmail.com', 'American International University-Bangladesh(AIUB)', '2009', 'CSE', '4.0'),
('samiatutor@gmail.com', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `thsc`
--

CREATE TABLE `thsc` (
  `email` varchar(100) NOT NULL,
  `insname` varchar(100) NOT NULL,
  `passingyear` varchar(4) NOT NULL,
  `board` varchar(100) NOT NULL,
  `fourthsub` varchar(11) NOT NULL,
  `result` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thsc`
--

INSERT INTO `thsc` (`email`, `insname`, `passingyear`, `board`, `fourthsub`, `result`) VALUES
('mina@gmail.com', 'Viqarunisa Noon School & College', '2004', 'Dhaka', 'Biology', '4'),
('samiatutor@gmail.com', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tmsc`
--

CREATE TABLE `tmsc` (
  `email` varchar(100) NOT NULL,
  `insname` varchar(100) NOT NULL,
  `passingyear` varchar(4) NOT NULL,
  `dept` varchar(100) NOT NULL,
  `subject` varchar(11) NOT NULL,
  `result` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tmsc`
--

INSERT INTO `tmsc` (`email`, `insname`, `passingyear`, `dept`, `subject`, `result`) VALUES
('mina@gmail.com', 'Bangladesh University of Technology(BUET)', '2010', 'CSE', 'ICT', '4.0'),
('samiatutor@gmail.com', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tssc`
--

CREATE TABLE `tssc` (
  `email` varchar(100) NOT NULL,
  `insname` varchar(100) NOT NULL,
  `passingyear` varchar(4) NOT NULL,
  `board` varchar(100) NOT NULL,
  `result` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tssc`
--

INSERT INTO `tssc` (`email`, `insname`, `passingyear`, `board`, `result`) VALUES
('mina@gmail.com', 'Viqarunnisa Non School', '2002', 'Dhaka', '4.00'),
('samiatutor@gmail.com', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tutorotherinfo`
--

CREATE TABLE `tutorotherinfo` (
  `email` varchar(100) NOT NULL,
  `medium` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `salary` varchar(40) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutorotherinfo`
--

INSERT INTO `tutorotherinfo` (`email`, `medium`, `subject`, `salary`, `status`) VALUES
('mina@gmail.com', 'English Version', 'Higher Math', '3000-5000', 'Available'),
('samiatutor@gmail.com', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tutorpersonalinfo`
--

CREATE TABLE `tutorpersonalinfo` (
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `phoneno` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutorpersonalinfo`
--

INSERT INTO `tutorpersonalinfo` (`email`, `name`, `dob`, `phoneno`, `location`, `gender`) VALUES
('mina@gmail.com', 'Mina', '1980-08-28', '01756787653', 'Basundhara', 'Female'),
('samiatutor@gmail.com', '', '0000-00-00', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `stueducationinfo`
--
ALTER TABLE `stueducationinfo`
  ADD KEY `semail_fk` (`email`);

--
-- Indexes for table `stupersonalinfo`
--
ALTER TABLE `stupersonalinfo`
  ADD KEY `semail_fk` (`email`);

--
-- Indexes for table `tbsc`
--
ALTER TABLE `tbsc`
  ADD KEY `temail_fk` (`email`);

--
-- Indexes for table `thsc`
--
ALTER TABLE `thsc`
  ADD KEY `temail_fk` (`email`);

--
-- Indexes for table `tmsc`
--
ALTER TABLE `tmsc`
  ADD KEY `temail_fk` (`email`);

--
-- Indexes for table `tssc`
--
ALTER TABLE `tssc`
  ADD KEY `temail_fk` (`email`);

--
-- Indexes for table `tutorotherinfo`
--
ALTER TABLE `tutorotherinfo`
  ADD KEY `temail_fk` (`email`);

--
-- Indexes for table `tutorpersonalinfo`
--
ALTER TABLE `tutorpersonalinfo`
  ADD KEY `temail_fk` (`email`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `stueducationinfo`
--
ALTER TABLE `stueducationinfo`
  ADD CONSTRAINT `stueducationinfo_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);

--
-- Constraints for table `stupersonalinfo`
--
ALTER TABLE `stupersonalinfo`
  ADD CONSTRAINT `stupersonalinfo_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);

--
-- Constraints for table `tbsc`
--
ALTER TABLE `tbsc`
  ADD CONSTRAINT `tbsc_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);

--
-- Constraints for table `thsc`
--
ALTER TABLE `thsc`
  ADD CONSTRAINT `thsc_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);

--
-- Constraints for table `tmsc`
--
ALTER TABLE `tmsc`
  ADD CONSTRAINT `tmsc_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);

--
-- Constraints for table `tssc`
--
ALTER TABLE `tssc`
  ADD CONSTRAINT `tssc_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);

--
-- Constraints for table `tutorotherinfo`
--
ALTER TABLE `tutorotherinfo`
  ADD CONSTRAINT `tutorotherinfo_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);

--
-- Constraints for table `tutorpersonalinfo`
--
ALTER TABLE `tutorpersonalinfo`
  ADD CONSTRAINT `tutorpersonalinfo_ibfk_1` FOREIGN KEY (`email`) REFERENCES `login` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
